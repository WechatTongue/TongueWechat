/**
 * Created by Srf on 2016/12/6.
 */
module.exports = () => {
  return{
    'font-size-base': '14px',
    'primary-color': '#008B8B'
  };
};
