

const host = 'http://www.ufengtech.xyz:8081';
export default host;
